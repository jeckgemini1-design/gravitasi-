import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setOverwriteOutput(true);
// WebGL: 'angle' works on most machines with a GPU. If rendering fails on a server
// without GPU, add the flag --gl=swangle to the render command.
Config.setChromiumOpenGlRenderer('angle');
