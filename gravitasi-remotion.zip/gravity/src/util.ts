import {useCurrentFrame} from 'remotion';

export const FPS = 30;
// Durasi audio narasi: 61.283 detik -> 1839 frame, pas dengan audio.
export const AUDIO_SEC = 61.283265;
export const TOTAL = Math.ceil(AUDIO_SEC * FPS);
export const sec = (s: number) => Math.round(s * FPS);

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const ease = (t: number) => t * t * (3 - 2 * t);
export const range = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
export const back = (p: number) => {
  const c1 = 1.70158, c3 = c1 + 1;
  const q = clamp(p);
  return 1 + c3 * Math.pow(q - 1, 3) + c1 * Math.pow(q - 1, 2);
};
export const rand = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
export const fmtG = (v: number) => v.toFixed(1).replace('.', ',') + 'x';

// Keyframe interpolasi halus: keys = [[waktu, nilai], ...]
export const kf = (t: number, keys: [number, number][]) => {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    if (t <= keys[i][0]) {
      const [t0, v0] = keys[i - 1];
      const [t1, v1] = keys[i];
      return lerp(v0, v1, ease((t - t0) / (t1 - t0)));
    }
  }
  return keys[keys.length - 1][1];
};

// Waktu absolut (detik) di dalam sebuah Sequence yang mulai pada `from` detik.
export const useT = (from: number) => useCurrentFrame() / FPS + sec(from) / FPS;
