import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Captions, FONT} from './overlay';
import {S1, S2, S3, S4, S5} from './scenes';
import {FPS, TOTAL, sec} from './util';

const SCENES = [
  {C: S1, from: 0, to: 5.0},
  {C: S2, from: 5.0, to: 21.2},
  {C: S3, from: 21.2, to: 38.8},
  {C: S4, from: 38.8, to: 50.0},
  {C: S5, from: 50.0, to: TOTAL / FPS},
];

export const Video: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  return (
    <AbsoluteFill style={{fontFamily: FONT, background: '#000'}}>
      <Audio src={staticFile('narasi.mp3')} />
      {SCENES.map((s, i) => (
        <Sequence key={i} from={sec(s.from)} durationInFrames={Math.round(s.to * FPS) - sec(s.from)}>
          <s.C />
        </Sequence>
      ))}
      <Captions t={t} />
    </AbsoluteFill>
  );
};
