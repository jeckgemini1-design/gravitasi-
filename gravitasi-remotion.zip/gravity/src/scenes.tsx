import React from 'react';
import * as THREE from 'three';
import {AbsoluteFill} from 'remotion';
import {Character, Chair, Cloud, Ground, House, Part, Puff, Stage, Tree, V3, INK} from './toon';
import {Flash, GravityPill, Sticker} from './overlay';
import {clamp, ease, fmtG, kf, lerp, rand, range, useT} from './util';

/* =========================================================
   SCENE 1  (0 - 5 dtk)  Hook: Bumi berguncang, gravitasi acak
   ========================================================= */
const GV = [1, 0.3, 2.6, 0.5, 3, 1.8, 0.4, 2.2, 1, 0.3];
const BLK = 0.55;
const gAt = (t: number) => {
  const i = Math.floor(t / BLK);
  const a = GV[i % GV.length], b = GV[(i + 1) % GV.length];
  return lerp(a, b, ease(clamp((t / BLK - i - 0.75) / 0.25)));
};

const CONT: V3[] = [[0.3, 0.6, 0.8], [-0.8, 0.2, 0.6], [0.7, -0.5, 0.5], [-0.4, -0.7, 0.6], [0.1, 0.9, -0.3]];
const Continent: React.FC<{dir: V3; r: number}> = ({dir, r}) => {
  const n = new THREE.Vector3(...dir).normalize();
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), n);
  return (
    <group quaternion={q} position={[n.x * 1.5, n.y * 1.5, n.z * 1.5]}>
      <Part a={[r]} color="#4ED47E" scale={[1, 1, 0.3]} ol={0.02} />
    </group>
  );
};

export const S1: React.FC = () => {
  const t = useT(0);
  const g = gAt(t);
  const shown = GV[Math.floor(t / BLK) % GV.length];
  const sy = 1 + (1 - g) * 0.07;
  const sx = 1 / Math.sqrt(sy);
  const hop = Math.abs(Math.sin(t * 4.2)) * Math.min(0.9, 0.8 / Math.pow(g, 0.6));
  const earthY = 1.5;
  const top = earthY + 1.5 * sy;
  const props: {c: string; s: 'sphere' | 'box' | 'cone'; a: number; sz: number}[] = [
    {c: '#FF5D5D', s: 'sphere', a: 0, sz: 0.28},
    {c: '#FFD23F', s: 'box', a: 1.6, sz: 0.4},
    {c: '#5BE08F', s: 'cone', a: 3.2, sz: 0.3},
    {c: '#5B8CFF', s: 'sphere', a: 4.7, sz: 0.24},
  ];
  return (
    <AbsoluteFill style={{background: 'linear-gradient(#241F66, #6F4BD8)'}}>
      <Stage cam={[0, 2.25, 15]} look={[0, 2.25, 0]} t={t} shake={g > 2 ? 0.05 : 0}>
        {Array.from({length: 26}).map((_, i) => (
          <Part key={i} a={[0.04 + rand(i) * 0.04]} color="#FFFFFF" ol={0}
            pos={[(rand(i + 3) - 0.5) * 9, rand(i + 9) * 9 - 1.5, -5]} scale={Array(3).fill(0.7 + 0.3 * Math.sin(t * 5 + i)) as V3} />
        ))}
        <group position={[0, earthY, 0]} scale={[sx, sy, sx]} rotation={[0.2, t * 0.9, 0]}>
          <Part a={[1.5]} color="#3FA9F5" ol={0.07}>
            {CONT.map((d, i) => <Continent key={i} dir={d} r={0.55 - i * 0.04} />)}
          </Part>
        </group>
        {props.map((p, i) => {
          const ang = t * 0.9 + p.a;
          const y = earthY + 0.2 + Math.sin(t * 3 + i) * 0.3 + (1.6 / g) * 0.5 * (1 + Math.sin(t * 2 + i * 2));
          return (
            <Part key={i} shape={p.s} a={p.s === 'box' ? [p.sz, p.sz, p.sz] : p.s === 'cone' ? [p.sz, p.sz * 1.6, 24] : [p.sz]}
              color={p.c} pos={[Math.cos(ang) * 2.0, y, Math.sin(ang) * 1.2 + 0.8]} rot={[t * 2, t * 1.5, 0]} />
          );
        })}
        <Character t={t} mood="wow" pos={[0, top + hop - 0.1, 0.2]} arms={0.5 + 0.4 * Math.sin(t * 8)} scale={0.8}
          sq={1 + Math.min(0.2, hop * 0.1) - (hop < 0.05 ? 0.15 : 0)} />
      </Stage>
      <GravityPill value={fmtG(shown)} t={t} shake={g > 2 ? 6 : 0} bg={shown < 1 ? '#C9F7F0' : shown > 1.5 ? '#FFB3C1' : '#FFFFFF'} />
      <Flash t={t} at={0} dur={0.3} />
    </AbsoluteFill>
  );
};

/* =========================================================
   SCENE 2  (5 - 21.2 dtk)  Jam 1: gravitasi 0,3x
   ========================================================= */
const hopCalc = (tt: number, T: number, H: number) => {
  const p = (((tt % T) + T) % T) / T;
  const air = 4 * p * (1 - p);
  const near = Math.min(p, 1 - p);
  return {y: H * air, air, s: 1 - 0.28 * Math.max(0, 1 - near / 0.06) + 0.12 * air};
};

export const S2: React.FC = () => {
  const t = useT(5);
  const ROOF = 2.23;
  let x = -0.6, y = 0, s = 1, air = 0;
  if (t < 9.2) {
    const h = hopCalc(t - 5, 2.0, 2.0); y = h.y; s = h.s; air = h.air;
  } else if (t < 11.0) {
    const p = (t - 9.2) / 1.8;
    x = -0.6 + 1.6 * p; y = ROOF * p + 2.7 * 4 * p * (1 - p); air = 4 * p * (1 - p); s = 1 + 0.15 * air;
  } else {
    const h = hopCalc(t - 11, 1.6, 1.6);
    x = 1.0; y = ROOF + h.y; s = h.s; air = h.air;
  }
  const moodB = t < 13.9 ? 'happy' : t < 15.4 ? 'wow' : 'dizzy';
  const kids: {c: string; x: number; off: number}[] = [
    {c: '#FF7AA2', x: -1.7, off: 0.0}, {c: '#5B8CFF', x: -0.4, off: 0.7}, {c: '#4ED8A0', x: 1.9, off: 1.3},
  ];
  return (
    <AbsoluteFill style={{background: 'linear-gradient(#8FEBDD, #FFF3B8)'}}>
      <Stage cam={[0, 2.25, 15]} look={[0, 2.25, 0]} t={t}>
        <Cloud pos={[-1.8 + Math.sin(t * 0.3) * 0.3, 6.6, -3]} s={1.1} />
        <Cloud pos={[2.0 + Math.cos(t * 0.25) * 0.3, 5.9, -3]} s={0.9} />
        <Ground color="#7BE08A" />
        <Tree pos={[-1.9, 0, -1.0]} />
        <House pos={[1.1, 0, -1.0]} />
        <Character t={t} mood={moodB} pos={[x, y, 0.4]} sq={s} arms={0.15 + 0.8 * air} legSwing={air * 0.5} />
        {kids.map((k, i) => {
          const sc = ease(range(t, 11.9 + 0.1 * i, 12.3 + 0.1 * i)) * 0.8;
          if (sc <= 0.01) return null;
          const h = hopCalc(t - 11.9 + k.off, 2.2, 2.6);
          return <Character key={i} t={t + i} color={k.c} mood={t < 16 ? 'happy' : 'dizzy'} pos={[k.x, h.y, 1.0]} sq={h.s} scale={sc} arms={0.15 + 0.9 * h.air} />;
        })}
        {t > 18.6 && Array.from({length: 34}).map((_, i) => {
          const v = 0.35 + 0.25 * rand(i + 9);
          let yy = 7.2 - 5 * rand(i + 50) - (t - 18.6) * v;
          yy = ((yy % 7.6) + 7.6) % 7.6;
          const a = ease(range(t, 18.6, 19.2));
          return <Part key={i} a={[0.07 * a]} color="#BDEBFF" ol={0.02} scale={[1, 1.5, 1]}
            pos={[-2 + 4 * rand(i) + Math.sin(t * 0.8 + i) * 0.15, yy, -1 + 2 * rand(i + 20)]} />;
        })}
      </Stage>
      <GravityPill value="0,3x" t={t} bg="#C9F7F0" />
      <Sticker t={t} at={5.2} top={345} text="Jam 1" size={64} />
      <Flash t={t} at={5.0} dur={0.2} />
    </AbsoluteFill>
  );
};

/* =========================================================
   SCENE 3  (21.2 - 38.8 dtk)  Jam 2: gravitasi 3x
   ========================================================= */
export const S3: React.FC = () => {
  const t = useT(21.2);
  const slam = 21.2;
  // Bobo ditekan ke tanah
  const bSq = kf(t, [[21.2, 1.3], [21.5, 0.62], [26.0, 0.62], [27.9, 0.46], [31.5, 0.46]]) + (t < 31.5 ? Math.sin(t * 28) * 0.012 : 0);
  const fall = (t0: number, y1: number) => Math.max(y1, 8 - 0.5 * 30 * Math.max(0, t - t0) ** 2);
  const BS = 1.1;
  const bobH = 1.85 * BS * bSq;
  const k1Y = fall(26.0, bobH), k2Y = fall(27.2, bobH + 0.9);
  const faint = ease(range(t, 31.6, 32.3));
  const gone = ease(range(t, 33.0, 33.3));
  const pale = t > 29.8;
  const moodAll = t < 31.6 ? 'strain' : 'faint';
  // pose akhir saat pingsan
  const bx = lerp(-1.1, -1.5, faint), kx1 = lerp(-1.1, 0.0, faint), kx2 = lerp(-1.1, 1.4, faint);
  const pass = (a: number) => (1 - gone) * a;
  // anak di kursi
  const cx = 0.3;
  const tip = ease(range(t, 34.4, 34.85));
  const drop = Math.max(0, t - 34.4);
  const kidY = t < 34.4 ? 0.85 : Math.max(0, 0.85 - 0.5 * 40 * drop * drop);
  const land = t >= 34.95;
  const shock = t >= 34.95 && t < 35.5 ? 0.12 * (1 - (t - 34.95) / 0.55) : 0;
  const shakeAmt = Math.max(0, 0.25 * (1 - (t - slam) / 0.5)) * (t > slam ? 1 : 0) + shock;
  return (
    <AbsoluteFill style={{background: 'linear-gradient(#3A1F6B, #C0437F)'}}>
      <Stage cam={[0, 2.25, 15]} look={[0, 2.25, 0]} t={t} shake={shakeAmt}>
        <Ground color="#4A2A7A" />
        {/* panah tekanan */}
        {[-1.6, 0, 1.6].map((px, i) => (
          <group key={i} position={[px, 6.6 - Math.abs(Math.sin(t * 4 + i)) * 0.5, -1]}>
            <Part shape="box" a={[0.35, 0.9, 0.1]} color="#FFFFFF" opacity={0.45} pos={[0, 0.7, 0]} />
            <Part shape="cone" a={[0.5, 0.7, 4]} color="#FFFFFF" opacity={0.45} rot={[0, Math.PI / 4, Math.PI]} />
          </group>
        ))}
        {/* Bobo + dua anak di punggung */}
        {gone < 1 && (
          <group scale={[1 - gone, 1 - gone, 1 - gone]}>
            <Character t={t} mood={moodAll} pos={[bx, 0, 0.4]} rotZ={faint * 1.45} sq={bSq} scale={BS}
              headColor={pale ? '#FFF1D6' : undefined} feetColor={pale ? '#FF3B3B' : undefined}
              feetScale={pale ? 1.7 : 1} arms={0.05} />
            {t > 26.0 && <Character t={t} color="#FF7AA2" mood={moodAll} pos={[kx1, k1Y * (1 - faint), 0.6]} rotZ={-faint * 1.45} scale={0.6} sq={0.8} arms={0.9} />}
            {t > 27.2 && <Character t={t} color="#5B8CFF" mood={moodAll} pos={[kx2, k2Y * (1 - faint), 0.6]} rotZ={faint * 1.45} scale={0.6} sq={0.75} arms={0.9} />}
          </group>
        )}
        {/* anak di kursi */}
        {t > 33.3 && (
          <group>
            <Chair pos={[cx, 0, 0]} rotZ={tip * 0.9 + (land ? 0.1 : 0)} />
            {/* penggaris 1 m */}
            <Part shape="box" a={[0.16, 3.2, 0.08]} color="#FFE08A" pos={[-1.8, 1.6, -0.5]} ol={0.03} />
            {[0, 1, 2, 3].map((i) => <Part key={i} shape="box" a={[0.4, 0.07, 0.1]} color={INK} ol={0} pos={[-1.62, 0.02 + i * 1.0, -0.45]} />)}
            <Character t={t} color="#4ED8A0" scale={0.8}
              mood={land ? 'faint' : t > 34.4 ? 'wow' : 'happy'}
              pos={[cx + (land ? 0.9 : tip * 0.5), kidY, 0.3]}
              rotZ={land ? 1.5 : tip * 0.9} sq={land ? 0.75 : 1} arms={t > 34.4 && !land ? 1 : 0.1} />
            {land && t < 35.4 && <Puff pos={[cx + 0.6, 0.15, 0.8]} r={0.9 * range(t, 34.95, 35.3)} color="#FFE08A" opacity={0.5 * (1 - range(t, 35.0, 35.4))} />}
          </group>
        )}
        {/* retak */}
        {t > 37.3 && [0, 1, 2].map((i) => (
          <Part key={i} shape="box" a={[0.7, 0.07, 0.05]} color="#FFFFFF" ol={0.02}
            pos={[cx + 0.9 + (i - 1) * 0.55, 0.9 + (i % 2) * 0.4, 1.2]} rot={[0, 0, 0.9 - i * 0.9]}
            scale={[ease(range(t, 37.3 + i * 0.1, 37.5 + i * 0.1)), 1, 1]} />
        ))}
      </Stage>
      <GravityPill value="3,0x" t={t} bg="#FFB3C1" shake={4} />
      <Sticker t={t} at={21.5} top={345} text="Jam 2" bg="#FF8FA3" size={64} />
      <Sticker t={t} at={34.95} until={36.6} top={760} text="Bruk!" rot={6} size={120} bg="#FFFFFF" />
      <Sticker t={t} at={37.4} until={38.8} top={760} text="Krak!" rot={-6} size={120} bg="#FFFFFF" />
      <Sticker t={t} at={34.0} until={36.9} top={1000} left="82%" text="1 m = 3 m" size={58} bg="#FFE08A" rot={5} />
      <Flash t={t} at={21.2} dur={0.35} />
    </AbsoluteFill>
  );
};

/* =========================================================
   SCENE 4  (38.8 - 50 dtk)  Kota runtuh + pesawat jatuh
   ========================================================= */
const B = [
  {x: -2.5, w: 0.95, h: 2.8, c: '#6C5CE7'}, {x: -1.25, w: 1.1, h: 4.4, c: '#FF8A7A'},
  {x: 0.05, w: 1.0, h: 3.4, c: '#4ED8A0'}, {x: 1.3, w: 1.15, h: 4.9, c: '#FFD23F'},
  {x: 2.55, w: 0.9, h: 3.0, c: '#5B8CFF'},
];

export const S4: React.FC = () => {
  const t = useT(38.8);
  const sq = kf(t, [[38.8, 1], [39.6, 0.9], [42.1, 0.92], [42.4, 0.74], [43.1, 1.12], [43.6, 1.08], [44.3, 0.72], [45.1, 0.7], [46.3, 0.55]]);
  const crumble = ease(range(t, 45.4, 46.4));
  const hit = t > 49.1;
  const ex = range(t, 49.1, 49.7);
  // pesawat
  let px = -3.6 + ((t - 47.0) / 1.2) * 3.0, py = 5.4 + Math.sin(t * 8) * 0.08, pitch = 0, roll = 0;
  if (t >= 48.2) {
    const tau = t - 48.2;
    px = -0.6 + 1.2 * tau; py = 5.4 - 0.5 * 14 * tau * tau;
    pitch = -1.3 * ease(clamp(tau / 0.5)); roll = tau * 6;
  }
  return (
    <AbsoluteFill style={{background: 'linear-gradient(#5A2D82, #FF8A5B)'}}>
      <Stage cam={[0, 2.25, 15]} look={[0, 2.25, 0]} t={t} shake={t > 42 ? 0.05 + 0.08 * crumble : 0.02}>
        <Part a={[0.9]} color="#FFE08A" ol={0.05} pos={[-1.8, 6.0, -6]} />
        <Ground color="#3A2A55" w={14} d={8} />
        {B.map((b, i) => {
          const lean = (i % 2 ? 1 : -1) * 0.5 * crumble * (0.6 + rand(i) * 0.8);
          return (
            <group key={i} position={[b.x, -crumble * 0.25, 0]} rotation={[0, 0, lean]} scale={[1 + (1 - sq) * 0.2, sq, 1]}>
              <Part shape="box" a={[b.w, b.h, 1.0]} color={b.c} pos={[0, b.h / 2, 0]} />
              {Array.from({length: Math.floor(b.h / 0.85)}).map((_, r) => [-0.22, 0.22].map((wx, c) => (
                <Part key={`${r}-${c}`} shape="box" a={[0.22, 0.34, 0.05]} ol={0.02}
                  color={(r + c + i) % 3 ? '#FFF1A8' : '#8A7FBF'} pos={[wx * (b.w / 0.95), 0.7 + r * 0.8, 0.52]} />
              )))}
            </group>
          );
        })}
        {t > 45.6 && [0, 1, 2, 3, 4, 5].map((i) => {
          const p = range(t, 45.6 + i * 0.05, 47.2);
          return <Puff key={i} pos={[-2.4 + i * 1.0, 0.5 + p * 1.6, 1.2]} r={0.6 * Math.sin(p * Math.PI) + 0.05} color="#EADFFF" />;
        })}
        {t > 47.0 && !hit && (
          <group position={[px, py, 1.0]} rotation={[roll, 0, pitch]} scale={[1.2, 1.2, 1.2]}>
            <Part shape="caps" a={[0.3, 1.6]} color="#FFFFFF" rot={[0, 0, Math.PI / 2]} />
            <Part a={[0.3]} color="#FF5D5D" pos={[1.15, 0, 0]} />
            <Part shape="box" a={[0.6, 0.07, 2.6]} color="#FF5D5D" pos={[0.1, -0.05, 0]} />
            <Part shape="box" a={[0.4, 0.7, 0.07]} color="#FF5D5D" pos={[-1.0, 0.4, 0]} rot={[0, 0, -0.3]} />
            {[0.5, 0.15, -0.2].map((wx, i) => <Part key={i} a={[0.07]} color="#7EE0FF" ol={0.015} pos={[wx, 0.12, 0.28]} />)}
          </group>
        )}
        {hit && [0, 1, 2, 3, 4].map((i) => {
          const r = (0.5 + rand(i) * 0.5) * Math.sin(ex * Math.PI) * 0.8;
          return <Puff key={i} r={r} color={['#FFD23F', '#FF8A3D', '#FFFFFF', '#FF5D5D', '#FFB347'][i]}
            pos={[0.5 + (rand(i + 4) - 0.5) * 1.8, 0.6 + rand(i + 8) * 1.3, 1.4]} />;
        })}
      </Stage>
      <GravityPill value="3,0x" t={t} bg="#FFB3C1" shake={5} />
      <Sticker t={t} at={49.2} until={50} top={760} text="Dhuar!" rot={5} size={120} bg="#FFFFFF" />
      <Flash t={t} at={38.8} dur={0.2} />
    </AbsoluteFill>
  );
};

/* =========================================================
   SCENE 5  (50 - 61.3 dtk)  Hari ketiga, jam berapa gravitasi berikutnya?
   ========================================================= */
export const S5: React.FC = () => {
  const t = useT(50);
  const spin = t >= 56.3;
  const minute = spin ? -((t - 56.3) * 720) : -Math.floor(t * 2) * 6;
  const hour = spin ? -((t - 56.3) * 60) : -t * 4;
  const rad = (d: number) => (d * Math.PI) / 180;
  const cta = t >= 58.6;
  const bobMood = cta ? 'happy' : spin ? 'wow' : 'strain';
  const q = Math.floor(t * 9);
  return (
    <AbsoluteFill style={{background: 'linear-gradient(#10123A, #2B2A6E)'}}>
      <Stage cam={[0, 2.25, 15]} look={[0, 2.25, 0]} t={t} shake={spin && !cta ? 0.03 : 0}>
        {Array.from({length: 22}).map((_, i) => (
          <Part key={i} a={[0.05]} color="#FFFFFF" ol={0} pos={[(rand(i) - 0.5) * 4.4, rand(i + 7) * 6 - 0.5, -4]} scale={Array(3).fill(0.6 + 0.4 * Math.sin(t * 4 + i)) as V3} />
        ))}
        <Ground color="#1E2060" />
        <group position={[0, 4.0, 0]} scale={Array(3).fill(0.9 * (1 + (spin && !cta ? 0.04 * Math.sin(t * 30) : 0))) as V3}>
          <Part shape="cyl" a={[1.65, 1.65, 0.3, 48]} color="#FF8A5B" rot={[Math.PI / 2, 0, 0]} pos={[0, 0, -0.05]} />
          <Part shape="cyl" a={[1.45, 1.45, 0.34, 48]} color="#FFF6DE" rot={[Math.PI / 2, 0, 0]} pos={[0, 0, 0]} ol={0.03} />
          {Array.from({length: 12}).map((_, i) => (
            <Part key={i} shape="box" a={[0.1, i % 3 ? 0.18 : 0.3, 0.08]} color={INK} ol={0}
              pos={[Math.sin(rad(i * 30)) * 1.22, Math.cos(rad(i * 30)) * 1.22, 0.2]} rot={[0, 0, -rad(i * 30)]} />
          ))}
          <group position={[0, 0, 0.25]} rotation={[0, 0, rad(hour)]}><Part shape="box" a={[0.14, 0.8, 0.07]} color={INK} pos={[0, 0.4, 0]} ol={0} /></group>
          <group position={[0, 0, 0.3]} rotation={[0, 0, rad(minute)]}><Part shape="box" a={[0.1, 1.15, 0.07]} color="#FF5D5D" pos={[0, 0.57, 0]} ol={0} /></group>
          <Part a={[0.13]} color={INK} pos={[0, 0, 0.34]} ol={0} />
        </group>
        <Character t={t} mood={bobMood} pos={[0, 0, 1.2]} scale={1.2} look={0} arms={cta ? 0.9 + 0.1 * Math.sin(t * 12) : 0.15} legSwing={cta ? Math.sin(t * 10) * 0.3 : 0} />
      </Stage>
      <GravityPill value={t >= 56.3 && t < 58.6 ? fmtG(GV[q % GV.length]) : '?,?x'} t={t} bg="#FFFFFF" shake={spin ? 5 : 0} />
      <Sticker t={t} at={50.07} until={58.6} top={345} text="Hari ke-3" bg="#FF8FA3" size={64} />
      <Sticker t={t} at={58.7} top={345} text="Follow ya!" bg="#FFD23F" size={72} rot={-3} />
      <Flash t={t} at={50.0} dur={0.25} />
    </AbsoluteFill>
  );
};
