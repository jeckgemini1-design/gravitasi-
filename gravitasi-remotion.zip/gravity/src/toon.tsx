import React from 'react';
import * as THREE from 'three';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import {useVideoConfig} from 'remotion';

export const INK = '#1B1A3A';
export type V3 = [number, number, number];
type Shape = 'sphere' | 'box' | 'cyl' | 'cone' | 'caps' | 'oct';

// Gradient 3 tingkat -> bayangan bergaya kartun (cel shading)
let _g: THREE.DataTexture | null = null;
const grad = () => {
  if (!_g) {
    _g = new THREE.DataTexture(new Uint8Array([80, 160, 255]), 3, 1, THREE.RedFormat);
    _g.minFilter = _g.magFilter = THREE.NearestFilter;
    _g.needsUpdate = true;
  }
  return _g;
};

const Geo: React.FC<{shape: Shape; a: number[]}> = ({shape, a}) => {
  switch (shape) {
    case 'box': return <boxGeometry args={[a[0], a[1], a[2]]} />;
    case 'cyl': return <cylinderGeometry args={[a[0], a[1], a[2], a[3] ?? 32]} />;
    case 'cone': return <coneGeometry args={[a[0], a[1], a[2] ?? 32]} />;
    case 'caps': return <capsuleGeometry args={[a[0], a[1], 8, 20]} />;
    case 'oct': return <octahedronGeometry args={[a[0]]} />;
    default: return <sphereGeometry args={[a[0], 32, 22]} />;
  }
};

// Skala mesh kontur (inverted hull) supaya tebal garis konsisten
const oScale = (shape: Shape, a: number[], ol: number): V3 => {
  const f = (d: number) => (d + 2 * ol) / d;
  switch (shape) {
    case 'box': return [f(a[0]), f(a[1]), f(a[2])];
    case 'cyl': { const r = Math.max(a[0], a[1]); return [(r + ol) / r, f(a[2]), (r + ol) / r]; }
    case 'cone': return [(a[0] + ol) / a[0], f(a[1]), (a[0] + ol) / a[0]];
    case 'caps': { const L = a[1] + 2 * a[0]; return [(a[0] + ol) / a[0], f(L), (a[0] + ol) / a[0]]; }
    default: { const s = 1 + ol / a[0]; return [s, s, s]; }
  }
};

export const Part: React.FC<{
  shape?: Shape; a: number[]; color: string; pos?: V3; rot?: V3; scale?: V3;
  ol?: number; opacity?: number; children?: React.ReactNode;
}> = ({shape = 'sphere', a, color, pos = [0, 0, 0], rot = [0, 0, 0], scale = [1, 1, 1], ol = 0.04, opacity = 1, children}) => (
  <group position={pos} rotation={rot} scale={scale}>
    <mesh>
      <Geo shape={shape} a={a} />
      {opacity < 1
        ? <meshBasicMaterial color={color} transparent opacity={opacity} />
        : <meshToonMaterial color={color} gradientMap={grad()} />}
    </mesh>
    {ol > 0 && opacity >= 1 && (
      <mesh scale={oScale(shape, a, ol)}>
        <Geo shape={shape} a={a} />
        <meshBasicMaterial color={INK} side={THREE.BackSide} />
      </mesh>
    )}
    {children}
  </group>
);

/* ---------------- Karakter "Bobo" ---------------- */
export type Mood = 'happy' | 'wow' | 'strain' | 'dizzy' | 'faint';

export const Character: React.FC<{
  t: number; color?: string; mood?: Mood; pos?: V3; rotZ?: number; sq?: number; scale?: number;
  arms?: number; headColor?: string; feetColor?: string; feetScale?: number; legSwing?: number; look?: number;
}> = ({
  t, color = '#FFB534', mood = 'happy', pos = [0, 0, 0], rotZ = 0, sq = 1, scale = 1,
  arms = 0.1, headColor, feetColor = '#FF6F59', feetScale = 1, legSwing = 0, look = 0,
}) => {
  const sx = 1 / Math.sqrt(Math.max(0.2, sq));
  const hc = headColor ?? color;
  const eyeY = 1.28;
  const ex = (s: number) => s * 0.2;
  const ang = (s: number) => s * (0.35 + arms * 2.5);
  const Eye = (s: number) => {
    if (mood === 'faint') {
      return (
        <group key={s} position={[ex(s), eyeY, 0.5]}>
          <mesh rotation={[0, 0, 0.78]}><boxGeometry args={[0.24, 0.05, 0.04]} /><meshBasicMaterial color={INK} /></mesh>
          <mesh rotation={[0, 0, -0.78]}><boxGeometry args={[0.24, 0.05, 0.04]} /><meshBasicMaterial color={INK} /></mesh>
        </group>
      );
    }
    if (mood === 'strain') {
      return (
        <group key={s} position={[ex(s), eyeY, 0.5]}>
          <mesh rotation={[0, 0, s * -0.45]}><boxGeometry args={[0.22, 0.06, 0.04]} /><meshBasicMaterial color={INK} /></mesh>
          <mesh position={[0, 0.17, 0]} rotation={[0, 0, s * 0.5]}><boxGeometry args={[0.24, 0.05, 0.04]} /><meshBasicMaterial color={INK} /></mesh>
        </group>
      );
    }
    const r = mood === 'wow' ? 0.17 : mood === 'dizzy' ? 0.16 : 0.13;
    const pr = mood === 'wow' ? 0.05 : 0.075;
    const px = mood === 'dizzy' ? Math.cos(t * 14 + s) * 0.06 : look * 0.04;
    const py = mood === 'dizzy' ? Math.sin(t * 14 + s) * 0.06 : 0;
    return (
      <Part key={s} a={[r]} color="#FFFFFF" pos={[ex(s), eyeY, 0.43]} scale={[1, 1.15, 0.6]} ol={0.02}>
        <Part a={[pr]} color={INK} pos={[px, py, 0.1]} ol={0} />
      </Part>
    );
  };
  return (
    <group position={pos} rotation={[0, 0, rotZ]} scale={[sx * scale, sq * scale, sx * scale]}>
      {/* badan */}
      <Part a={[0.42]} color={color} pos={[0, 0.5, 0]} scale={[1, 1.1, 0.95]}>
        <Part a={[0.28]} color="#FFEBB0" pos={[0, -0.02, 0.28]} scale={[1, 1, 0.45]} ol={0} />
      </Part>
      {/* kepala */}
      <Part a={[0.55]} color={hc} pos={[0, 1.2, 0]} />
      <Part shape="cone" a={[0.09, 0.32, 16]} color="#FF5D5D" pos={[0.05, 1.9, 0]} rot={[0, 0, -0.25]} ol={0.03} />
      {Eye(-1)}{Eye(1)}
      {/* pipi */}
      <Part a={[0.08]} color="#FF8FA3" pos={[-0.36, 1.12, 0.38]} scale={[1, 0.7, 0.4]} ol={0} />
      <Part a={[0.08]} color="#FF8FA3" pos={[0.36, 1.12, 0.38]} scale={[1, 0.7, 0.4]} ol={0} />
      {/* mulut */}
      {mood === 'happy' && (
        <mesh position={[0, 1.1, 0.52]} rotation={[0, 0, Math.PI]}><torusGeometry args={[0.1, 0.028, 8, 16, Math.PI]} /><meshBasicMaterial color={INK} /></mesh>
      )}
      {mood === 'strain' && (
        <mesh position={[0, 1.02, 0.52]}><torusGeometry args={[0.1, 0.028, 8, 16, Math.PI]} /><meshBasicMaterial color={INK} /></mesh>
      )}
      {(mood === 'wow' || mood === 'dizzy' || mood === 'faint') && (
        <mesh position={[0, 1.04, 0.52]} scale={[1, 1.3, 0.4]}><sphereGeometry args={[0.08, 16, 12]} /><meshBasicMaterial color={INK} /></mesh>
      )}
      {/* lengan */}
      {[-1, 1].map((s) => (
        <group key={s} position={[s * 0.4, 0.72, 0]} rotation={[0, 0, ang(s)]}>
          <Part shape="caps" a={[0.09, 0.25]} color={color} pos={[0, -0.22, 0]} />
        </group>
      ))}
      {/* kaki */}
      {[-1, 1].map((s) => (
        <group key={s} position={[s * 0.2, 0.2, 0]} rotation={[s * legSwing, 0, 0]}>
          <Part a={[0.16]} color={feetColor} pos={[0, -0.12, 0.05]} scale={[feetScale, 0.7 * feetScale, 1.3 * feetScale]} />
        </group>
      ))}
      {/* keringat */}
      {mood === 'strain' && [0, 1].map((i) => (
        <Part key={i} a={[0.07]} color="#7EE0FF" ol={0.02}
          pos={[0.62, 1.55 - ((t * 1.3 + i * 0.5) % 1) * 0.8, 0.2]} scale={[1, 1.4, 1]} />
      ))}
      {/* bintang pusing */}
      {(mood === 'dizzy' || mood === 'faint') && [0, 1, 2].map((i) => {
        const a = t * 4 + (i * Math.PI * 2) / 3;
        return <Part key={i} shape="oct" a={[0.1]} color="#FFD23F" ol={0.02} pos={[Math.cos(a) * 0.65, 2.1, Math.sin(a) * 0.4]} rot={[a, a, 0]} />;
      })}
    </group>
  );
};

/* ---------------- Properti lingkungan ---------------- */
export const Ground: React.FC<{color: string; w?: number; d?: number}> = ({color, w = 40, d = 40}) => (
  <Part shape="box" a={[w, 0.6, d]} color={color} pos={[0, -0.3, 0]} ol={0.06} />
);

export const Cloud: React.FC<{pos: V3; s?: number}> = ({pos, s = 1}) => (
  <group position={pos} scale={[s, s, s]}>
    <Part a={[0.6]} color="#FFFFFF" pos={[0, 0, 0]} ol={0.05} />
    <Part a={[0.45]} color="#FFFFFF" pos={[0.7, -0.12, 0]} ol={0.05} />
    <Part a={[0.45]} color="#FFFFFF" pos={[-0.7, -0.12, 0]} ol={0.05} />
  </group>
);

export const House: React.FC<{pos: V3}> = ({pos}) => (
  <group position={pos}>
    <Part shape="box" a={[1.8, 2.0, 1.5]} color="#FF8A7A" pos={[0, 1.0, 0]} />
    <Part shape="box" a={[2.05, 0.25, 1.75]} color="#6C5CE7" pos={[0, 2.1, 0]} />
    <Part shape="box" a={[0.45, 0.9, 0.06]} color="#FFE08A" pos={[0.3, 0.45, 0.76]} ol={0.03} />
    <Part shape="box" a={[0.4, 0.4, 0.06]} color="#BDEBFF" pos={[-0.5, 1.2, 0.76]} ol={0.03} />
  </group>
);

export const Tree: React.FC<{pos: V3; s?: number}> = ({pos, s = 1}) => (
  <group position={pos} scale={[s, s, s]}>
    <Part shape="cyl" a={[0.14, 0.18, 0.9]} color="#9B6B43" pos={[0, 0.45, 0]} />
    <Part a={[0.7]} color="#3FCB7B" pos={[0, 1.35, 0]} />
    <Part a={[0.5]} color="#5BE08F" pos={[0.3, 1.75, 0.1]} />
  </group>
);

export const Chair: React.FC<{pos: V3; rotZ?: number}> = ({pos, rotZ = 0}) => (
  <group position={pos} rotation={[0, 0, rotZ]}>
    <Part shape="box" a={[1.0, 0.12, 0.9]} color="#C58B5A" pos={[0, 0.78, 0]} ol={0.03} />
    <Part shape="box" a={[0.1, 0.9, 0.9]} color="#C58B5A" pos={[-0.45, 1.25, 0]} ol={0.03} />
    {[[-0.42, -0.36], [0.42, -0.36], [-0.42, 0.36], [0.42, 0.36]].map(([x, z], i) => (
      <Part key={i} shape="cyl" a={[0.05, 0.05, 0.75]} color="#9B6B43" pos={[x, 0.38, z]} ol={0.025} />
    ))}
  </group>
);

export const Puff: React.FC<{pos: V3; r: number; color?: string; opacity?: number}> = ({pos, r, color = '#FFFFFF', opacity = 1}) => (
  r > 0.01 ? <Part a={[r]} color={color} pos={pos} ol={opacity >= 1 ? 0.04 : 0} opacity={opacity} /> : null
);

/* ---------------- Panggung (kamera + cahaya) ---------------- */
const Rig: React.FC<{pos: V3; look: V3}> = ({pos, look}) => {
  const camera = useThree((s) => s.camera);
  camera.position.set(...pos);
  camera.lookAt(...look);
  camera.updateProjectionMatrix();
  return null;
};

export const Stage: React.FC<{cam: V3; look: V3; t: number; shake?: number; children: React.ReactNode}> = ({cam, look, t, shake = 0, children}) => {
  const {width, height} = useVideoConfig();
  const dx = Math.sin(t * 91) * shake;
  const dy = Math.cos(t * 77) * shake;
  return (
    <ThreeCanvas width={width} height={height} camera={{fov: 38, position: cam, near: 0.1, far: 100}} style={{position: 'absolute', inset: 0}} flat>
      <Rig pos={[cam[0] + dx, cam[1] + dy, cam[2]]} look={look} />
      <ambientLight intensity={0.9} />
      <directionalLight position={[3, 8, 7]} intensity={2.2} />
      {children}
    </ThreeCanvas>
  );
};
