import React from 'react';
import {AbsoluteFill} from 'remotion';
import {INK} from './toon';
import {back, clamp} from './util';

export const FONT = "'Baloo 2','Fredoka','Arial Rounded MT Bold','Trebuchet MS',system-ui,sans-serif";

// [mulai, selesai, teks] dalam detik, disinkronkan dengan jeda di audio narasi.
const CAPS: [number, number, string][] = [
  [0.0, 2.2, 'Bayangkan gravitasi Bumi berubah...'],
  [2.8, 3.5, 'acak...'],
  [3.7, 5.0, 'setiap jam.'],
  [5.2, 6.2, 'Jam pertama,'],
  [6.4, 8.9, 'gravitasi turun jadi tiga puluh persen!'],
  [9.2, 11.5, 'Kamu bisa melompat setinggi atap rumah.'],
  [11.9, 13.6, 'Anak-anak pasti berpesta.'],
  [13.9, 15.6, 'Tapi udara ikut menipis.'],
  [16.0, 17.1, 'Napas pendek,'],
  [17.2, 18.5, 'kepala pusing,'],
  [18.6, 21.0, 'dan hujan melayang pelan seperti salju.'],
  [21.6, 23.2, 'Lalu, tanpa peringatan,'],
  [23.4, 25.6, 'gravitasi melonjak tiga kali lipat.'],
  [26.1, 29.2, 'Tubuhmu terasa seperti membawa dua orang di punggung.'],
  [29.7, 31.3, 'Darah tertarik ke kaki,'],
  [31.5, 33.0, 'banyak orang pingsan.'],
  [33.4, 36.9, 'Jatuh dari kursi terasa seperti jatuh dari tiga meter.'],
  [37.3, 38.8, 'Tulang mulai retak.'],
  [39.0, 41.8, 'Gedung dan jembatan tidak dirancang untuk ini.'],
  [42.2, 43.0, 'Ditarik,'],
  [43.2, 44.1, 'dilepas,'],
  [44.2, 45.3, 'ditarik lagi,'],
  [45.4, 46.8, 'sampai menyerah.'],
  [47.0, 47.9, 'Dan pesawat?'],
  [48.2, 49.8, 'Jatuh seperti batu.'],
  [50.0, 51.0, 'Hari ketiga,'],
  [51.2, 52.8, 'kamu tidak lagi bertanya'],
  [52.9, 54.2, '"apa yang terjadi?"'],
  [54.6, 56.0, 'Kamu hanya bertanya...'],
  [56.3, 58.4, '"jam berapa gravitasi berikutnya?"'],
  [58.6, 61.3, 'Follow untuk skenario gila berikutnya.'],
];

export const Captions: React.FC<{t: number}> = ({t}) => {
  const c = CAPS.find(([a, b]) => t >= a && t < b);
  if (!c) return null;
  const p = back((t - c[0]) / 0.18);
  return (
    <div style={{
      position: 'absolute', left: 70, right: 70, bottom: 360, textAlign: 'center',
      fontFamily: FONT, fontWeight: 800, fontSize: 92, lineHeight: 1.05, color: '#FFFFFF',
      WebkitTextStroke: `18px ${INK}`, paintOrder: 'stroke fill', letterSpacing: 1,
      transform: `scale(${0.8 + 0.2 * p})`, opacity: clamp((t - c[0]) / 0.06),
    }}>
      {c[2]}
    </div>
  );
};

export const GravityPill: React.FC<{value: string; bg?: string; shake?: number; t: number}> = ({value, bg = '#FFFFFF', shake = 0, t}) => (
  <div style={{
    position: 'absolute', top: 140, left: '50%',
    transform: `translate(calc(-50% + ${Math.sin(t * 80) * shake}px), ${Math.cos(t * 67) * shake}px)`,
    display: 'flex', alignItems: 'baseline', gap: 22, padding: '2px 46px 14px',
    background: bg, border: `8px solid ${INK}`, borderRadius: 80,
    boxShadow: `0 10px 0 ${INK}`, fontFamily: FONT, color: INK, fontWeight: 800,
  }}>
    <span style={{fontSize: 44}}>Gravitasi</span>
    <span style={{fontSize: 120, lineHeight: 1}}>{value}</span>
  </div>
);

export const Sticker: React.FC<{t: number; at: number; until?: number; text: string; top: number; left?: number | string; bg?: string; rot?: number; size?: number}> = ({
  t, at, until = 999, text, top, left = '50%', bg = '#FFD23F', rot = -4, size = 84,
}) => {
  if (t < at || t > until) return null;
  const p = back((t - at) / 0.25);
  return (
    <div style={{
      position: 'absolute', top, left, transform: `translateX(-50%) rotate(${rot}deg) scale(${p})`,
      padding: '4px 44px 16px', background: bg, border: `9px solid ${INK}`, borderRadius: 44,
      boxShadow: `0 10px 0 ${INK}`, fontFamily: FONT, fontWeight: 800, fontSize: size, color: INK, whiteSpace: 'nowrap',
    }}>
      {text}
    </div>
  );
};

export const Flash: React.FC<{t: number; at: number; color?: string; dur?: number}> = ({t, at, color = '#FFFFFF', dur = 0.25}) => {
  const p = (t - at) / dur;
  if (p < 0 || p > 1) return null;
  return <AbsoluteFill style={{background: color, opacity: 1 - p, pointerEvents: 'none'}} />;
};
