# Gravitasi Berubah Tiap Jam (Shorts 60 detik, 3D toon)

Vertikal 1080x1920, 30 fps, 1839 frame = 61,28 detik (sama dengan audio narasi).

## Cara render
1. Install Node.js 18+.
2. `npm install`
3. Preview: `npm start` (Remotion Studio)
4. Render: `npm run render`  -> hasil di `out/gravitasi-shorts.mp4`

Kalau render gagal di mesin tanpa GPU/WebGL, tambahkan `--gl=swangle`:
`npx remotion render src/index.ts Gravitasi out/gravitasi-shorts.mp4 --gl=swangle`

## Struktur
- `public/narasi.mp3`  audio ElevenLabs
- `src/scenes.tsx`     5 scene 3D (hook, jam 1, jam 2, kota+pesawat, penutup)
- `src/toon.tsx`       material toon (cel shading + outline), karakter Bobo, properti
- `src/overlay.tsx`    caption (waktu per kalimat di `CAPS`), pill gravitasi, stiker
- `src/Video.tsx`      urutan scene + audio

## Ganti audio
Timing scene ada di `src/Video.tsx` (SCENES) dan caption di `CAPS` (`overlay.tsx`).
Durasi total diatur di `AUDIO_SEC` pada `src/util.ts`.

## Font
Memakai stack font rounded (Baloo 2 / Fredoka / Arial Rounded). Untuk tampilan konsisten,
pasang `@remotion/google-fonts` lalu `loadFont()` Baloo2 di `overlay.tsx`.
